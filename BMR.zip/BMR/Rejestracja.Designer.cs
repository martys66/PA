﻿namespace BMR
{
    partial class Rejestracja
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Login_l = new System.Windows.Forms.Label();
            this.Haslo_l = new System.Windows.Forms.Label();
            this.login_tb = new System.Windows.Forms.TextBox();
            this.haslo_tb = new System.Windows.Forms.TextBox();
            this.Haslo2_l = new System.Windows.Forms.Label();
            this.haslo2_tb = new System.Windows.Forms.TextBox();
            this.Zarejestrujsie_b = new System.Windows.Forms.Button();
            this.Powrot1_b = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // Login_l
            // 
            this.Login_l.AutoSize = true;
            this.Login_l.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Login_l.Location = new System.Drawing.Point(238, 72);
            this.Login_l.Name = "Login_l";
            this.Login_l.Size = new System.Drawing.Size(101, 39);
            this.Login_l.TabIndex = 0;
            this.Login_l.Text = "Login";
            // 
            // Haslo_l
            // 
            this.Haslo_l.AutoSize = true;
            this.Haslo_l.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Haslo_l.Location = new System.Drawing.Point(238, 160);
            this.Haslo_l.Name = "Haslo_l";
            this.Haslo_l.Size = new System.Drawing.Size(105, 39);
            this.Haslo_l.TabIndex = 1;
            this.Haslo_l.Text = "Hasło";
            // 
            // login_tb
            // 
            this.login_tb.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.login_tb.Location = new System.Drawing.Point(388, 75);
            this.login_tb.Name = "login_tb";
            this.login_tb.Size = new System.Drawing.Size(200, 38);
            this.login_tb.TabIndex = 2;
            // 
            // haslo_tb
            // 
            this.haslo_tb.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.haslo_tb.Location = new System.Drawing.Point(388, 163);
            this.haslo_tb.Name = "haslo_tb";
            this.haslo_tb.Size = new System.Drawing.Size(200, 38);
            this.haslo_tb.TabIndex = 3;
            this.haslo_tb.UseSystemPasswordChar = true;
            // 
            // Haslo2_l
            // 
            this.Haslo2_l.AutoSize = true;
            this.Haslo2_l.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Haslo2_l.Location = new System.Drawing.Point(112, 252);
            this.Haslo2_l.Name = "Haslo2_l";
            this.Haslo2_l.Size = new System.Drawing.Size(231, 39);
            this.Haslo2_l.TabIndex = 4;
            this.Haslo2_l.Text = "Powtórz hasło";
            // 
            // haslo2_tb
            // 
            this.haslo2_tb.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.haslo2_tb.Location = new System.Drawing.Point(388, 252);
            this.haslo2_tb.Name = "haslo2_tb";
            this.haslo2_tb.PasswordChar = '*';
            this.haslo2_tb.Size = new System.Drawing.Size(200, 38);
            this.haslo2_tb.TabIndex = 5;
            this.haslo2_tb.UseSystemPasswordChar = true;
            // 
            // Zarejestrujsie_b
            // 
            this.Zarejestrujsie_b.Location = new System.Drawing.Point(388, 321);
            this.Zarejestrujsie_b.Name = "Zarejestrujsie_b";
            this.Zarejestrujsie_b.Size = new System.Drawing.Size(200, 84);
            this.Zarejestrujsie_b.TabIndex = 6;
            this.Zarejestrujsie_b.Text = "Zarejestruj się";
            this.Zarejestrujsie_b.UseVisualStyleBackColor = true;
            this.Zarejestrujsie_b.Click += new System.EventHandler(this.Zarejestrujsie_b_Click);
            // 
            // Powrot1_b
            // 
            this.Powrot1_b.Location = new System.Drawing.Point(643, 12);
            this.Powrot1_b.Name = "Powrot1_b";
            this.Powrot1_b.Size = new System.Drawing.Size(145, 67);
            this.Powrot1_b.TabIndex = 7;
            this.Powrot1_b.Text = "Powrót do menu";
            this.Powrot1_b.UseVisualStyleBackColor = true;
            this.Powrot1_b.Click += new System.EventHandler(this.Powrot1_b_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(643, 272);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(116, 17);
            this.checkBox1.TabIndex = 9;
            this.checkBox1.Text = "Nie jestem robotem";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // Rejestracja
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.Powrot1_b);
            this.Controls.Add(this.Zarejestrujsie_b);
            this.Controls.Add(this.haslo2_tb);
            this.Controls.Add(this.Haslo2_l);
            this.Controls.Add(this.haslo_tb);
            this.Controls.Add(this.login_tb);
            this.Controls.Add(this.Haslo_l);
            this.Controls.Add(this.Login_l);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Rejestracja";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BMR";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Login_l;
        private System.Windows.Forms.Label Haslo_l;
        private System.Windows.Forms.TextBox login_tb;
        private System.Windows.Forms.TextBox haslo_tb;
        private System.Windows.Forms.Label Haslo2_l;
        private System.Windows.Forms.TextBox haslo2_tb;
        private System.Windows.Forms.Button Zarejestrujsie_b;
        private System.Windows.Forms.Button Powrot1_b;
        private System.Windows.Forms.CheckBox checkBox1;
    }
}