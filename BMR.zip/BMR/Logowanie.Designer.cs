﻿namespace BMR
{
    partial class Logowanie
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LoginLogowanie_l = new System.Windows.Forms.Label();
            this.HasloLogowanie_l = new System.Windows.Forms.Label();
            this.loginLogowanie_tb = new System.Windows.Forms.TextBox();
            this.hasloLogowanie_tb = new System.Windows.Forms.TextBox();
            this.Zalogujsie_b = new System.Windows.Forms.Button();
            this.PowrotLogowanie_b = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LoginLogowanie_l
            // 
            this.LoginLogowanie_l.AutoSize = true;
            this.LoginLogowanie_l.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.LoginLogowanie_l.Location = new System.Drawing.Point(187, 72);
            this.LoginLogowanie_l.Name = "LoginLogowanie_l";
            this.LoginLogowanie_l.Size = new System.Drawing.Size(101, 39);
            this.LoginLogowanie_l.TabIndex = 1;
            this.LoginLogowanie_l.Text = "Login";
            // 
            // HasloLogowanie_l
            // 
            this.HasloLogowanie_l.AutoSize = true;
            this.HasloLogowanie_l.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.HasloLogowanie_l.Location = new System.Drawing.Point(187, 191);
            this.HasloLogowanie_l.Name = "HasloLogowanie_l";
            this.HasloLogowanie_l.Size = new System.Drawing.Size(105, 39);
            this.HasloLogowanie_l.TabIndex = 2;
            this.HasloLogowanie_l.Text = "Hasło";
            // 
            // loginLogowanie_tb
            // 
            this.loginLogowanie_tb.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.loginLogowanie_tb.Location = new System.Drawing.Point(323, 75);
            this.loginLogowanie_tb.Name = "loginLogowanie_tb";
            this.loginLogowanie_tb.Size = new System.Drawing.Size(200, 38);
            this.loginLogowanie_tb.TabIndex = 3;
            // 
            // hasloLogowanie_tb
            // 
            this.hasloLogowanie_tb.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.hasloLogowanie_tb.Location = new System.Drawing.Point(323, 194);
            this.hasloLogowanie_tb.Name = "hasloLogowanie_tb";
            this.hasloLogowanie_tb.Size = new System.Drawing.Size(200, 38);
            this.hasloLogowanie_tb.TabIndex = 4;
            this.hasloLogowanie_tb.UseSystemPasswordChar = true;
            // 
            // Zalogujsie_b
            // 
            this.Zalogujsie_b.Location = new System.Drawing.Point(323, 289);
            this.Zalogujsie_b.Name = "Zalogujsie_b";
            this.Zalogujsie_b.Size = new System.Drawing.Size(200, 84);
            this.Zalogujsie_b.TabIndex = 7;
            this.Zalogujsie_b.Text = "Zaloguj się";
            this.Zalogujsie_b.UseVisualStyleBackColor = true;
            this.Zalogujsie_b.Click += new System.EventHandler(this.Zalogujsie_b_Click);
            // 
            // PowrotLogowanie_b
            // 
            this.PowrotLogowanie_b.Location = new System.Drawing.Point(643, 12);
            this.PowrotLogowanie_b.Name = "PowrotLogowanie_b";
            this.PowrotLogowanie_b.Size = new System.Drawing.Size(145, 67);
            this.PowrotLogowanie_b.TabIndex = 8;
            this.PowrotLogowanie_b.Text = "Powrót do menu";
            this.PowrotLogowanie_b.UseVisualStyleBackColor = true;
            this.PowrotLogowanie_b.Click += new System.EventHandler(this.PowrotLogowanie_b_Click);
            // 
            // Logowanie
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.PowrotLogowanie_b);
            this.Controls.Add(this.Zalogujsie_b);
            this.Controls.Add(this.hasloLogowanie_tb);
            this.Controls.Add(this.loginLogowanie_tb);
            this.Controls.Add(this.HasloLogowanie_l);
            this.Controls.Add(this.LoginLogowanie_l);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "Logowanie";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Logowanie";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LoginLogowanie_l;
        private System.Windows.Forms.Label HasloLogowanie_l;
        private System.Windows.Forms.TextBox loginLogowanie_tb;
        private System.Windows.Forms.TextBox hasloLogowanie_tb;
        private System.Windows.Forms.Button Zalogujsie_b;
        private System.Windows.Forms.Button PowrotLogowanie_b;
    }
}