﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BMR
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void Rejestracja_b_Click(object sender, EventArgs e)
        {
            this.Hide();                     // ukrywanie okna Form1
            new Rejestracja().Show();       // po kliknięciu w przycisk "Rejestracja" przechodzi do okna "Rejestracja"




        }

        private void Logowanie_b_Click(object sender, EventArgs e)
        {
            this.Hide();                // ukrywanie okna Form1
            new Logowanie().Show();    // po kliknięciu w przycisk "Logowanie" przechodzi do okna "Logowanie"

        }

        private void Exit_b_Click(object sender, EventArgs e)
        {
            Application.Exit();       // zamykanie aplikacji
        }
    }
}
