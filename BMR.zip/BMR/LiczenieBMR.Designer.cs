﻿namespace BMR
{
    partial class LiczenieBMR
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nazwaUżytkownika_l = new System.Windows.Forms.Label();
            this.wiekL = new System.Windows.Forms.Label();
            this.płećL = new System.Windows.Forms.Label();
            this.wzrostL = new System.Windows.Forms.Label();
            this.wagaL = new System.Windows.Forms.Label();
            this.PłećCB = new System.Windows.Forms.ComboBox();
            this.wiek_tb = new System.Windows.Forms.TextBox();
            this.wzrost_tb = new System.Windows.Forms.TextBox();
            this.waga_tb = new System.Windows.Forms.TextBox();
            this.buttonObliczBMRiCPM = new System.Windows.Forms.Button();
            this.labelBMR1 = new System.Windows.Forms.Label();
            this.labelBMR2 = new System.Windows.Forms.Label();
            this.aktywność_l = new System.Windows.Forms.Label();
            this.aktywnoscCB = new System.Windows.Forms.ComboBox();
            this.labelCPM = new System.Windows.Forms.Label();
            this.labelCPM2 = new System.Windows.Forms.Label();
            this.buttonAnaliza = new System.Windows.Forms.Button();
            this.buttonWyjscie = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // nazwaUżytkownika_l
            // 
            this.nazwaUżytkownika_l.AutoSize = true;
            this.nazwaUżytkownika_l.Location = new System.Drawing.Point(13, 13);
            this.nazwaUżytkownika_l.Name = "nazwaUżytkownika_l";
            this.nazwaUżytkownika_l.Size = new System.Drawing.Size(13, 13);
            this.nazwaUżytkownika_l.TabIndex = 0;
            this.nazwaUżytkownika_l.Text = "0";
            // 
            // wiekL
            // 
            this.wiekL.AutoSize = true;
            this.wiekL.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.wiekL.Location = new System.Drawing.Point(65, 120);
            this.wiekL.Name = "wiekL";
            this.wiekL.Size = new System.Drawing.Size(52, 24);
            this.wiekL.TabIndex = 1;
            this.wiekL.Text = "Wiek";
            // 
            // płećL
            // 
            this.płećL.AutoSize = true;
            this.płećL.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.płećL.Location = new System.Drawing.Point(66, 68);
            this.płećL.Name = "płećL";
            this.płećL.Size = new System.Drawing.Size(51, 24);
            this.płećL.TabIndex = 2;
            this.płećL.Text = "Płeć";
            // 
            // wzrostL
            // 
            this.wzrostL.AutoSize = true;
            this.wzrostL.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.wzrostL.Location = new System.Drawing.Point(12, 177);
            this.wzrostL.Name = "wzrostL";
            this.wzrostL.Size = new System.Drawing.Size(105, 24);
            this.wzrostL.TabIndex = 3;
            this.wzrostL.Text = "Wzrost(cm)";
            // 
            // wagaL
            // 
            this.wagaL.AutoSize = true;
            this.wagaL.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.wagaL.Location = new System.Drawing.Point(26, 229);
            this.wagaL.Name = "wagaL";
            this.wagaL.Size = new System.Drawing.Size(91, 24);
            this.wagaL.TabIndex = 4;
            this.wagaL.Text = "Waga(kg)";
            // 
            // PłećCB
            // 
            this.PłećCB.Items.AddRange(new object[] {
            "Kobieta",
            "Mężczyzna"});
            this.PłećCB.Location = new System.Drawing.Point(133, 71);
            this.PłećCB.Name = "PłećCB";
            this.PłećCB.Size = new System.Drawing.Size(121, 21);
            this.PłećCB.TabIndex = 6;
            // 
            // wiek_tb
            // 
            this.wiek_tb.Location = new System.Drawing.Point(133, 124);
            this.wiek_tb.Name = "wiek_tb";
            this.wiek_tb.Size = new System.Drawing.Size(121, 20);
            this.wiek_tb.TabIndex = 7;
            // 
            // wzrost_tb
            // 
            this.wzrost_tb.Location = new System.Drawing.Point(133, 177);
            this.wzrost_tb.Name = "wzrost_tb";
            this.wzrost_tb.Size = new System.Drawing.Size(121, 20);
            this.wzrost_tb.TabIndex = 8;
            // 
            // waga_tb
            // 
            this.waga_tb.Location = new System.Drawing.Point(133, 234);
            this.waga_tb.Name = "waga_tb";
            this.waga_tb.Size = new System.Drawing.Size(121, 20);
            this.waga_tb.TabIndex = 9;
            // 
            // buttonObliczBMRiCPM
            // 
            this.buttonObliczBMRiCPM.Location = new System.Drawing.Point(133, 334);
            this.buttonObliczBMRiCPM.Name = "buttonObliczBMRiCPM";
            this.buttonObliczBMRiCPM.Size = new System.Drawing.Size(121, 58);
            this.buttonObliczBMRiCPM.TabIndex = 10;
            this.buttonObliczBMRiCPM.Text = "Oblicz BMR i CPM";
            this.buttonObliczBMRiCPM.UseVisualStyleBackColor = true;
            this.buttonObliczBMRiCPM.Click += new System.EventHandler(this.buttonObliczBMRiCPM_Click);
            // 
            // labelBMR1
            // 
            this.labelBMR1.AutoSize = true;
            this.labelBMR1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.labelBMR1.Location = new System.Drawing.Point(349, 13);
            this.labelBMR1.Name = "labelBMR1";
            this.labelBMR1.Size = new System.Drawing.Size(203, 26);
            this.labelBMR1.TabIndex = 11;
            this.labelBMR1.Text = "Twoje BMR wynosi:";
            this.labelBMR1.Click += new System.EventHandler(this.labelBMR1_Click);
            // 
            // labelBMR2
            // 
            this.labelBMR2.AutoSize = true;
            this.labelBMR2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.labelBMR2.Location = new System.Drawing.Point(554, 13);
            this.labelBMR2.Name = "labelBMR2";
            this.labelBMR2.Size = new System.Drawing.Size(24, 26);
            this.labelBMR2.TabIndex = 12;
            this.labelBMR2.Text = "0";
            // 
            // aktywność_l
            // 
            this.aktywność_l.AutoSize = true;
            this.aktywność_l.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.aktywność_l.Location = new System.Drawing.Point(17, 275);
            this.aktywność_l.Name = "aktywność_l";
            this.aktywność_l.Size = new System.Drawing.Size(100, 24);
            this.aktywność_l.TabIndex = 13;
            this.aktywność_l.Text = "Aktywność";
            // 
            // aktywnoscCB
            // 
            this.aktywnoscCB.Items.AddRange(new object[] {
            "Brak",
            "Niska",
            "Średnia",
            "Wysoka",
            "Bardzo wysoka"});
            this.aktywnoscCB.Location = new System.Drawing.Point(133, 278);
            this.aktywnoscCB.Name = "aktywnoscCB";
            this.aktywnoscCB.Size = new System.Drawing.Size(121, 21);
            this.aktywnoscCB.TabIndex = 14;
            // 
            // labelCPM
            // 
            this.labelCPM.AutoSize = true;
            this.labelCPM.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.labelCPM.Location = new System.Drawing.Point(349, 39);
            this.labelCPM.Name = "labelCPM";
            this.labelCPM.Size = new System.Drawing.Size(203, 26);
            this.labelCPM.TabIndex = 15;
            this.labelCPM.Text = "Twoje CPM wynosi:";
            this.labelCPM.Click += new System.EventHandler(this.labelCPM_Click);
            // 
            // labelCPM2
            // 
            this.labelCPM2.AutoSize = true;
            this.labelCPM2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.labelCPM2.Location = new System.Drawing.Point(554, 39);
            this.labelCPM2.Name = "labelCPM2";
            this.labelCPM2.Size = new System.Drawing.Size(24, 26);
            this.labelCPM2.TabIndex = 16;
            this.labelCPM2.Text = "0";
            // 
            // buttonAnaliza
            // 
            this.buttonAnaliza.Location = new System.Drawing.Point(399, 129);
            this.buttonAnaliza.Name = "buttonAnaliza";
            this.buttonAnaliza.Size = new System.Drawing.Size(259, 72);
            this.buttonAnaliza.TabIndex = 17;
            this.buttonAnaliza.Text = "Pełna analiza";
            this.buttonAnaliza.UseVisualStyleBackColor = true;
            this.buttonAnaliza.Visible = false;
            this.buttonAnaliza.Click += new System.EventHandler(this.buttonAnaliza_Click);
            // 
            // buttonWyjscie
            // 
            this.buttonWyjscie.Location = new System.Drawing.Point(399, 251);
            this.buttonWyjscie.Name = "buttonWyjscie";
            this.buttonWyjscie.Size = new System.Drawing.Size(259, 72);
            this.buttonWyjscie.TabIndex = 20;
            this.buttonWyjscie.Text = "Wyjście\r\n";
            this.buttonWyjscie.UseVisualStyleBackColor = true;
            this.buttonWyjscie.Visible = false;
            this.buttonWyjscie.Click += new System.EventHandler(this.buttonWyjscie_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.label1.Location = new System.Drawing.Point(616, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 26);
            this.label1.TabIndex = 21;
            this.label1.Text = "kcal";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.label2.Location = new System.Drawing.Point(616, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 26);
            this.label2.TabIndex = 22;
            this.label2.Text = "kcal";
            // 
            // LiczenieBMR
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonWyjscie);
            this.Controls.Add(this.buttonAnaliza);
            this.Controls.Add(this.labelCPM2);
            this.Controls.Add(this.labelCPM);
            this.Controls.Add(this.aktywnoscCB);
            this.Controls.Add(this.aktywność_l);
            this.Controls.Add(this.labelBMR2);
            this.Controls.Add(this.labelBMR1);
            this.Controls.Add(this.buttonObliczBMRiCPM);
            this.Controls.Add(this.waga_tb);
            this.Controls.Add(this.wzrost_tb);
            this.Controls.Add(this.wiek_tb);
            this.Controls.Add(this.PłećCB);
            this.Controls.Add(this.wagaL);
            this.Controls.Add(this.wzrostL);
            this.Controls.Add(this.płećL);
            this.Controls.Add(this.wiekL);
            this.Controls.Add(this.nazwaUżytkownika_l);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "LiczenieBMR";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BMR";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label nazwaUżytkownika_l;
        private System.Windows.Forms.Label wiekL;
        private System.Windows.Forms.Label płećL;
        private System.Windows.Forms.Label wzrostL;
        private System.Windows.Forms.Label wagaL;
        private System.Windows.Forms.ComboBox PłećCB;
        private System.Windows.Forms.TextBox wiek_tb;
        private System.Windows.Forms.TextBox wzrost_tb;
        private System.Windows.Forms.TextBox waga_tb;
        private System.Windows.Forms.Button buttonObliczBMRiCPM;
        private System.Windows.Forms.Label labelBMR1;
        private System.Windows.Forms.Label labelBMR2;
        private System.Windows.Forms.Label aktywność_l;
        private System.Windows.Forms.ComboBox aktywnoscCB;
        private System.Windows.Forms.Label labelCPM;
        private System.Windows.Forms.Label labelCPM2;
        private System.Windows.Forms.Button buttonAnaliza;
        private System.Windows.Forms.Button buttonWyjscie;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}