﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BMR
{
    
    public partial class LiczenieBMR : Form
    {
        public string NazwaUżytkownika;
        public string BMR_d = "";
        public string CPM_d = "";
        
        int wzrost,waga,wiek;     // definiuje zmienne
        double BMR;

        

        public LiczenieBMR(Logowanie logowanie)   // "dziedziczenie" z okna logowanie
        {

            InitializeComponent();                               
            nazwaUżytkownika_l.Text = logowanie.nazwaUżytkownika;  // pobranie loginu z okna Logowanie 
            NazwaUżytkownika = nazwaUżytkownika_l.Text;
           
        }

        private void buttonObliczBMRiCPM_Click(object sender, EventArgs e)
        {
            wiek = Convert.ToInt32(wiek_tb.Text);      // zamiana string(textBox) na int  
            wzrost = Convert.ToInt32(wzrost_tb.Text);
            waga = Convert.ToInt32(waga_tb.Text);
            double brakAktywności = 1.2;
            double niskaAktywność = 1.4;
            double średniaAktywność = 1.6;
            double wysokaAktywność = 1.8;
            double bardzoWysokaAktywność = 2.0;
            

            if (PłećCB.SelectedItem.ToString() == "Kobieta")                   // jeśli w comboBoxie zostanie wybrana "Kobieta" to:
            {
                BMR = Math.Round(((9.99*waga) + (6.25*wzrost) - (4.92*wiek))-161);         // obliczanie BMR dla kobiety
                labelBMR2.Text = BMR.ToString();                                  // przepisanie wartości BMR do odpowiedniego labela
            }
            else if(PłećCB.SelectedItem.ToString() == "Mężczyzna")            // jeśli w comboBoxie zostanie wybrany "Mężczyzna" to:
            {
                BMR = Math.Round(((9.99 * waga) + (6.25* wzrost) - (4.92* wiek))+5);      // obliczanie BMR dla kobiety
                labelBMR2.Text = BMR.ToString();                                 // przepisanie wartości BMR do odpowiedniego labela
            }
            // obliczanie CPM dla obliczonego BMR i poszczególnych aktywności fizycznych
            if(aktywnoscCB.SelectedItem.ToString() == "Brak")
            {
                labelCPM2.Text = Math.Round((BMR * brakAktywności)).ToString();
            }
            else if(aktywnoscCB.SelectedItem.ToString() == "Niska")
            {
                labelCPM2.Text = Math.Round((BMR * niskaAktywność)).ToString();
            }
            else if (aktywnoscCB.SelectedItem.ToString() == "Średnia")
            {
                labelCPM2.Text = Math.Round((BMR * średniaAktywność)).ToString();
            }
            else if (aktywnoscCB.SelectedItem.ToString() == "Wysoka")
            {
                labelCPM2.Text = Math.Round((BMR * wysokaAktywność)).ToString();
            }
            else if (aktywnoscCB.SelectedItem.ToString() == "Bardzo wysoka")
            {
                labelCPM2.Text = Math.Round((BMR * bardzoWysokaAktywność)).ToString();
            }

            // pojawienie się przycisków w oknie LiczenieBMR
            buttonAnaliza.Visible = true;
            buttonWyjscie.Visible = true;


        }
        // informacje na temat BMR po kliknięciu w label z BMR
        private void labelBMR1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("BMR określa ile kalorii na dobę spala organizm, by utrzymać podstawowe funkcje życiowe.", "BMR", MessageBoxButtons.OK);
        }

        // informacje na temat CPM
        private void labelCPM_Click(object sender, EventArgs e)
        {
            MessageBox.Show("CPM określa ile kalorii na dobę spala organizm przy określonej aktywności fizycznej.", "CPM", MessageBoxButtons.OK);
        }

        private void buttonAnaliza_Click(object sender, EventArgs e)
        {
            // po kliknięcie w przycisk analizy wartości BMR i CPM z labeli są wpisywane do zmiennych i otwiera się nowe okno Analiza
            BMR_d = labelBMR2.Text;
            CPM_d = labelCPM2.Text;
            this.Close();
            new Analiza(this).Show();          
        }

        private void buttonWyjscie_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
