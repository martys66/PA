﻿namespace BMR
{
    partial class Analiza
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.labelNazwaUżytkownikaAnaliza = new System.Windows.Forms.Label();
            this.ComboBoxTwojCel = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBoxMakroskladniki = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.chartWykresKolowy = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.buttonPrzelicz = new System.Windows.Forms.Button();
            this.textBoxBialko = new System.Windows.Forms.TextBox();
            this.textBoxWeglowodany = new System.Windows.Forms.TextBox();
            this.textBoxTluszcze = new System.Windows.Forms.TextBox();
            this.labelPodsumowanie = new System.Windows.Forms.Label();
            this.labelKalorie = new System.Windows.Forms.Label();
            this.labelKalorieLiczba = new System.Windows.Forms.Label();
            this.labelZmiana = new System.Windows.Forms.Label();
            this.labelZmianaLiczba = new System.Windows.Forms.Label();
            this.textBoxBialkoGram = new System.Windows.Forms.TextBox();
            this.textBoxWeglowodanyGram = new System.Windows.Forms.TextBox();
            this.textBoxTluszczeGramy = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.buttonKcalNaGramBialko = new System.Windows.Forms.Button();
            this.buttonKcalNaGraWeglowodany = new System.Windows.Forms.Button();
            this.buttonKcalNaGramTluszcze = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.chartWykresKolowy)).BeginInit();
            this.SuspendLayout();
            // 
            // labelNazwaUżytkownikaAnaliza
            // 
            this.labelNazwaUżytkownikaAnaliza.AutoSize = true;
            this.labelNazwaUżytkownikaAnaliza.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelNazwaUżytkownikaAnaliza.Location = new System.Drawing.Point(18, 14);
            this.labelNazwaUżytkownikaAnaliza.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelNazwaUżytkownikaAnaliza.Name = "labelNazwaUżytkownikaAnaliza";
            this.labelNazwaUżytkownikaAnaliza.Size = new System.Drawing.Size(35, 37);
            this.labelNazwaUżytkownikaAnaliza.TabIndex = 0;
            this.labelNazwaUżytkownikaAnaliza.Text = "0";
            // 
            // ComboBoxTwojCel
            // 
            this.ComboBoxTwojCel.FormattingEnabled = true;
            this.ComboBoxTwojCel.Items.AddRange(new object[] {
            "Utrzymanie wagi",
            "Redukcja",
            "Masa"});
            this.ComboBoxTwojCel.Location = new System.Drawing.Point(327, 83);
            this.ComboBoxTwojCel.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ComboBoxTwojCel.Name = "ComboBoxTwojCel";
            this.ComboBoxTwojCel.Size = new System.Drawing.Size(212, 28);
            this.ComboBoxTwojCel.TabIndex = 1;
            this.ComboBoxTwojCel.SelectedIndexChanged += new System.EventHandler(this.ComboBoxTwojCel_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(172, 77);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 37);
            this.label1.TabIndex = 2;
            this.label1.Text = "Twój cel:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(75, 142);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(244, 37);
            this.label2.TabIndex = 3;
            this.label2.Text = "Makroskładniki:";
            // 
            // comboBoxMakroskladniki
            // 
            this.comboBoxMakroskladniki.Enabled = false;
            this.comboBoxMakroskladniki.FormattingEnabled = true;
            this.comboBoxMakroskladniki.Items.AddRange(new object[] {
            "Standardowe",
            "Niestandardowe"});
            this.comboBoxMakroskladniki.Location = new System.Drawing.Point(327, 148);
            this.comboBoxMakroskladniki.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBoxMakroskladniki.Name = "comboBoxMakroskladniki";
            this.comboBoxMakroskladniki.Size = new System.Drawing.Size(212, 28);
            this.comboBoxMakroskladniki.TabIndex = 4;
            this.comboBoxMakroskladniki.SelectedIndexChanged += new System.EventHandler(this.comboBoxMakroskladniki_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(117, 246);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(203, 37);
            this.label3.TabIndex = 5;
            this.label3.Text = "Białko [kcal]:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(3, 306);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(311, 37);
            this.label4.TabIndex = 6;
            this.label4.Text = "Węglowodany [kcal]:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(76, 369);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(242, 37);
            this.label5.TabIndex = 7;
            this.label5.Text = "Tłuszcze [kcal]:";
            // 
            // chartWykresKolowy
            // 
            this.chartWykresKolowy.BorderlineWidth = 3;
            chartArea1.Name = "ChartArea1";
            this.chartWykresKolowy.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chartWykresKolowy.Legends.Add(legend1);
            this.chartWykresKolowy.Location = new System.Drawing.Point(603, 77);
            this.chartWykresKolowy.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.chartWykresKolowy.Name = "chartWykresKolowy";
            this.chartWykresKolowy.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Light;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series1.CustomProperties = "MinimumRelativePieSize=50";
            series1.Legend = "Legend1";
            series1.Name = "Makroskładniki";
            this.chartWykresKolowy.Series.Add(series1);
            this.chartWykresKolowy.Size = new System.Drawing.Size(579, 420);
            this.chartWykresKolowy.TabIndex = 8;
            this.chartWykresKolowy.Text = "chart1";
            // 
            // buttonPrzelicz
            // 
            this.buttonPrzelicz.Location = new System.Drawing.Point(327, 423);
            this.buttonPrzelicz.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonPrzelicz.Name = "buttonPrzelicz";
            this.buttonPrzelicz.Size = new System.Drawing.Size(214, 74);
            this.buttonPrzelicz.TabIndex = 9;
            this.buttonPrzelicz.Text = "Przelicz";
            this.buttonPrzelicz.UseVisualStyleBackColor = true;
            this.buttonPrzelicz.Click += new System.EventHandler(this.buttonPrzelicz_Click);
            // 
            // textBoxBialko
            // 
            this.textBoxBialko.Location = new System.Drawing.Point(327, 254);
            this.textBoxBialko.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxBialko.Name = "textBoxBialko";
            this.textBoxBialko.Size = new System.Drawing.Size(94, 26);
            this.textBoxBialko.TabIndex = 10;
            // 
            // textBoxWeglowodany
            // 
            this.textBoxWeglowodany.Location = new System.Drawing.Point(327, 314);
            this.textBoxWeglowodany.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxWeglowodany.Name = "textBoxWeglowodany";
            this.textBoxWeglowodany.Size = new System.Drawing.Size(94, 26);
            this.textBoxWeglowodany.TabIndex = 11;
            // 
            // textBoxTluszcze
            // 
            this.textBoxTluszcze.Location = new System.Drawing.Point(327, 377);
            this.textBoxTluszcze.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxTluszcze.Name = "textBoxTluszcze";
            this.textBoxTluszcze.Size = new System.Drawing.Size(94, 26);
            this.textBoxTluszcze.TabIndex = 12;
            // 
            // labelPodsumowanie
            // 
            this.labelPodsumowanie.AutoSize = true;
            this.labelPodsumowanie.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelPodsumowanie.Location = new System.Drawing.Point(3, 520);
            this.labelPodsumowanie.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelPodsumowanie.Name = "labelPodsumowanie";
            this.labelPodsumowanie.Size = new System.Drawing.Size(423, 37);
            this.labelPodsumowanie.TabIndex = 13;
            this.labelPodsumowanie.Text = "Tygodniowe podsumowanie:";
            this.labelPodsumowanie.Visible = false;
            // 
            // labelKalorie
            // 
            this.labelKalorie.AutoSize = true;
            this.labelKalorie.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelKalorie.Location = new System.Drawing.Point(34, 586);
            this.labelKalorie.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelKalorie.Name = "labelKalorie";
            this.labelKalorie.Size = new System.Drawing.Size(125, 37);
            this.labelKalorie.TabIndex = 14;
            this.labelKalorie.Text = "Kalorie:\r\n";
            this.labelKalorie.Visible = false;
            // 
            // labelKalorieLiczba
            // 
            this.labelKalorieLiczba.AutoSize = true;
            this.labelKalorieLiczba.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelKalorieLiczba.Location = new System.Drawing.Point(154, 586);
            this.labelKalorieLiczba.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelKalorieLiczba.Name = "labelKalorieLiczba";
            this.labelKalorieLiczba.Size = new System.Drawing.Size(35, 37);
            this.labelKalorieLiczba.TabIndex = 15;
            this.labelKalorieLiczba.Text = "0";
            this.labelKalorieLiczba.Visible = false;
            // 
            // labelZmiana
            // 
            this.labelZmiana.AutoSize = true;
            this.labelZmiana.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelZmiana.Location = new System.Drawing.Point(351, 586);
            this.labelZmiana.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelZmiana.Name = "labelZmiana";
            this.labelZmiana.Size = new System.Drawing.Size(134, 37);
            this.labelZmiana.TabIndex = 16;
            this.labelZmiana.Text = "Zmiana:";
            this.labelZmiana.Visible = false;
            // 
            // labelZmianaLiczba
            // 
            this.labelZmianaLiczba.AutoSize = true;
            this.labelZmianaLiczba.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelZmianaLiczba.Location = new System.Drawing.Point(477, 586);
            this.labelZmianaLiczba.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelZmianaLiczba.Name = "labelZmianaLiczba";
            this.labelZmianaLiczba.Size = new System.Drawing.Size(35, 37);
            this.labelZmianaLiczba.TabIndex = 17;
            this.labelZmianaLiczba.Text = "0";
            this.labelZmianaLiczba.Visible = false;
            // 
            // textBoxBialkoGram
            // 
            this.textBoxBialkoGram.Location = new System.Drawing.Point(446, 254);
            this.textBoxBialkoGram.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxBialkoGram.Name = "textBoxBialkoGram";
            this.textBoxBialkoGram.Size = new System.Drawing.Size(94, 26);
            this.textBoxBialkoGram.TabIndex = 18;
            // 
            // textBoxWeglowodanyGram
            // 
            this.textBoxWeglowodanyGram.Location = new System.Drawing.Point(446, 315);
            this.textBoxWeglowodanyGram.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxWeglowodanyGram.Name = "textBoxWeglowodanyGram";
            this.textBoxWeglowodanyGram.Size = new System.Drawing.Size(94, 26);
            this.textBoxWeglowodanyGram.TabIndex = 19;
            // 
            // textBoxTluszczeGramy
            // 
            this.textBoxTluszczeGramy.Location = new System.Drawing.Point(446, 377);
            this.textBoxTluszczeGramy.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxTluszczeGramy.Name = "textBoxTluszczeGramy";
            this.textBoxTluszczeGramy.Size = new System.Drawing.Size(94, 26);
            this.textBoxTluszczeGramy.TabIndex = 20;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(546, 248);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 37);
            this.label6.TabIndex = 21;
            this.label6.Text = "[g]";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.Location = new System.Drawing.Point(546, 314);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 37);
            this.label7.TabIndex = 22;
            this.label7.Text = "[g]";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label8.Location = new System.Drawing.Point(546, 377);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 37);
            this.label8.TabIndex = 23;
            this.label8.Text = "[g]";
            // 
            // buttonKcalNaGramBialko
            // 
            this.buttonKcalNaGramBialko.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonKcalNaGramBialko.Location = new System.Drawing.Point(424, 255);
            this.buttonKcalNaGramBialko.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonKcalNaGramBialko.Name = "buttonKcalNaGramBialko";
            this.buttonKcalNaGramBialko.Size = new System.Drawing.Size(20, 28);
            this.buttonKcalNaGramBialko.TabIndex = 24;
            this.buttonKcalNaGramBialko.UseVisualStyleBackColor = false;
            this.buttonKcalNaGramBialko.Click += new System.EventHandler(this.buttonKcalNaGramBialko_Click);
            // 
            // buttonKcalNaGraWeglowodany
            // 
            this.buttonKcalNaGraWeglowodany.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonKcalNaGraWeglowodany.Location = new System.Drawing.Point(424, 314);
            this.buttonKcalNaGraWeglowodany.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonKcalNaGraWeglowodany.Name = "buttonKcalNaGraWeglowodany";
            this.buttonKcalNaGraWeglowodany.Size = new System.Drawing.Size(20, 28);
            this.buttonKcalNaGraWeglowodany.TabIndex = 25;
            this.buttonKcalNaGraWeglowodany.UseVisualStyleBackColor = false;
            this.buttonKcalNaGraWeglowodany.Click += new System.EventHandler(this.buttonKcalNaGraWeglowodany_Click);
            // 
            // buttonKcalNaGramTluszcze
            // 
            this.buttonKcalNaGramTluszcze.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonKcalNaGramTluszcze.Location = new System.Drawing.Point(424, 377);
            this.buttonKcalNaGramTluszcze.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonKcalNaGramTluszcze.Name = "buttonKcalNaGramTluszcze";
            this.buttonKcalNaGramTluszcze.Size = new System.Drawing.Size(20, 28);
            this.buttonKcalNaGramTluszcze.TabIndex = 26;
            this.buttonKcalNaGramTluszcze.UseVisualStyleBackColor = false;
            this.buttonKcalNaGramTluszcze.Click += new System.EventHandler(this.buttonKcalNaGramTluszcze_Click);
            // 
            // Analiza
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 692);
            this.Controls.Add(this.buttonKcalNaGramTluszcze);
            this.Controls.Add(this.buttonKcalNaGraWeglowodany);
            this.Controls.Add(this.buttonKcalNaGramBialko);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBoxTluszczeGramy);
            this.Controls.Add(this.textBoxWeglowodanyGram);
            this.Controls.Add(this.textBoxBialkoGram);
            this.Controls.Add(this.labelZmianaLiczba);
            this.Controls.Add(this.labelZmiana);
            this.Controls.Add(this.labelKalorieLiczba);
            this.Controls.Add(this.labelKalorie);
            this.Controls.Add(this.labelPodsumowanie);
            this.Controls.Add(this.textBoxTluszcze);
            this.Controls.Add(this.textBoxWeglowodany);
            this.Controls.Add(this.textBoxBialko);
            this.Controls.Add(this.buttonPrzelicz);
            this.Controls.Add(this.chartWykresKolowy);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboBoxMakroskladniki);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ComboBoxTwojCel);
            this.Controls.Add(this.labelNazwaUżytkownikaAnaliza);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Analiza";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Analiza";
            this.Load += new System.EventHandler(this.Analiza_Load);
            ((System.ComponentModel.ISupportInitialize)(this.chartWykresKolowy)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelNazwaUżytkownikaAnaliza;
        private System.Windows.Forms.ComboBox ComboBoxTwojCel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBoxMakroskladniki;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartWykresKolowy;
        private System.Windows.Forms.Button buttonPrzelicz;
        private System.Windows.Forms.TextBox textBoxBialko;
        private System.Windows.Forms.TextBox textBoxWeglowodany;
        private System.Windows.Forms.TextBox textBoxTluszcze;
        private System.Windows.Forms.Label labelPodsumowanie;
        private System.Windows.Forms.Label labelKalorie;
        private System.Windows.Forms.Label labelKalorieLiczba;
        private System.Windows.Forms.Label labelZmiana;
        private System.Windows.Forms.Label labelZmianaLiczba;
        private System.Windows.Forms.TextBox textBoxBialkoGram;
        private System.Windows.Forms.TextBox textBoxWeglowodanyGram;
        private System.Windows.Forms.TextBox textBoxTluszczeGramy;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button buttonKcalNaGramBialko;
        private System.Windows.Forms.Button buttonKcalNaGraWeglowodany;
        private System.Windows.Forms.Button buttonKcalNaGramTluszcze;
    }
}