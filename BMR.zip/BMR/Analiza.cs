﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BMR
{
    public partial class Analiza : Form
    {
        
        LiczenieBMR originalForm1;
        public double CPM;
        public double bialko;
        public double weglowodany;
        public double tluszcze;
        public double makroskladniki;
        public double zmiana;
        public double tydzien;
        public Analiza(LiczenieBMR copyForm1)
        {
            originalForm1 = copyForm1;
            InitializeComponent();
        }

        private void Analiza_Load(object sender, EventArgs e)
        {
            // wpisanie wartości CPM z okna LiczenieBMR do 
            CPM = Convert.ToDouble(originalForm1.CPM_d);
            labelNazwaUżytkownikaAnaliza.Text = originalForm1.NazwaUżytkownika + ", twoje CPM wynosi " + CPM + " kcal";
            
            
        }

        private void ComboBoxTwojCel_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ComboBoxTwojCel.SelectedItem.ToString() == "Utrzymanie wagi" || ComboBoxTwojCel.SelectedItem.ToString() == "Redukcja" || ComboBoxTwojCel.SelectedItem.ToString() == "Masa")
            {
                comboBoxMakroskladniki.Enabled = true;
            }

            if (ComboBoxTwojCel.SelectedItem.ToString() == "Redukcja")
            {
                CPM -= Math.Round(CPM * 0.1);
                MessageBox.Show("Twoje CPM zmalało o 10%: " + CPM);
                labelNazwaUżytkownikaAnaliza.Text = originalForm1.NazwaUżytkownika + ", twoje CPM wynosi " + CPM + " kcal";
                ComboBoxTwojCel.Enabled = false;
                zmiana = CPM * (-7);

            }

            if (ComboBoxTwojCel.SelectedItem.ToString() == "Masa")
            {
                CPM += Math.Round(CPM * 0.2);
                MessageBox.Show("Twoje CPM wzrostło o 20%: " + CPM);
                labelNazwaUżytkownikaAnaliza.Text = originalForm1.NazwaUżytkownika + ", twoje CPM wynosi " + CPM + " kcal";
                ComboBoxTwojCel.Enabled = false;
                zmiana = (CPM * 7);
            }

            if (ComboBoxTwojCel.SelectedItem.ToString() == "Utrzymanie wagi")
            {
                MessageBox.Show("Twoje CPM ma tą samą wartość");
                ComboBoxTwojCel.Enabled = false;
                zmiana = CPM * 7;
                
            }


        }      
           
        void comboBoxMakroskladniki_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            

            if (comboBoxMakroskladniki.SelectedItem.ToString() == "Standardowe")
            {               
                bialko = CPM / 2.5;
                weglowodany = CPM / 2.5;
                tluszcze = CPM / 5;
                textBoxBialko.Text = bialko.ToString();
                textBoxWeglowodany.Text = weglowodany.ToString();
                textBoxTluszcze.Text = tluszcze.ToString();
            }
            else if (comboBoxMakroskladniki.SelectedItem.ToString() == "Niestandardowe")
            {          
                textBoxBialko.Text = "0";
                textBoxWeglowodany.Text = "0";
                textBoxTluszcze.Text = "0";              
                
            }
        }

        private void buttonPrzelicz_Click(object sender, EventArgs e)
        {

            makroskladniki = CPM;
            bialko = Convert.ToDouble(textBoxBialko.Text);
            weglowodany = Convert.ToDouble(textBoxWeglowodany.Text);
            tluszcze = Convert.ToDouble(textBoxTluszcze.Text);
            
            if(makroskladniki == (bialko+weglowodany+tluszcze))
            {
                chartWykresKolowy.Series[0].Points.Clear();
                               
                this.chartWykresKolowy.Series["Makroskładniki"].Points.AddXY("Węglowodany " + (Math.Round((weglowodany/ makroskladniki) * 100, 1) + "%"), weglowodany);
                this.chartWykresKolowy.Series["Makroskładniki"].Points.AddXY("Białko " + (Math.Round((bialko / makroskladniki) * 100, 1) + "%"), bialko);
                this.chartWykresKolowy.Series["Makroskładniki"].Points.AddXY("Tłuszcze " + (Math.Round((tluszcze / makroskladniki) * 100, 1) + "%"), tluszcze);

                labelPodsumowanie.Visible = true;
                labelKalorie.Visible = true;
                labelKalorieLiczba.Visible = true;
                labelZmiana.Visible = true;
                labelZmianaLiczba.Visible = true;

                labelKalorieLiczba.Text = Math.Round(CPM * 7).ToString() + " kcal";
                labelZmianaLiczba.Text = Math.Round(zmiana / 7000, 1).ToString() + " [kg]";

            }
            else if(makroskladniki > (bialko+weglowodany+tluszcze))
            {
                MessageBox.Show("Masz jeszcze: " + (makroskladniki-(bialko+weglowodany+tluszcze)) + " kalorii do rozdania!");                
            }
            else if((makroskladniki < (bialko + weglowodany + tluszcze)))
            {
                MessageBox.Show("Wartości są wieksze od określonego CPM, popraw je!");                
            }
            
            
        }

        private void buttonKcalNaGramBialko_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxBialkoGram.Text) || textBoxBialkoGram.Text == "0")
            {
                double a = Convert.ToDouble(textBoxBialko.Text);
                textBoxBialkoGram.Text = (a / 4).ToString();
            }
            else if(string.IsNullOrWhiteSpace(textBoxBialko.Text) || textBoxBialko.Text == "0")
            {
                double b = Convert.ToDouble(textBoxBialkoGram.Text);
                textBoxBialko.Text = (b*4).ToString();
            }
        }

        private void buttonKcalNaGraWeglowodany_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxWeglowodanyGram.Text) || textBoxWeglowodanyGram.Text == "0")
            {
                double a = Convert.ToDouble(textBoxWeglowodany.Text);
                textBoxWeglowodanyGram.Text = (a / 4).ToString();
            }
            else if (string.IsNullOrWhiteSpace(textBoxWeglowodany.Text) || textBoxWeglowodany.Text == "0")
            {
                double b = Convert.ToDouble(textBoxWeglowodanyGram.Text);
                textBoxWeglowodany.Text = (b * 4).ToString();
            }
        }

        private void buttonKcalNaGramTluszcze_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxTluszczeGramy.Text) || textBoxTluszczeGramy.Text == "0")
            {
                double a = Convert.ToDouble(textBoxTluszcze.Text);
                textBoxTluszczeGramy.Text = (a / 9).ToString();
            }
            else if (string.IsNullOrWhiteSpace(textBoxTluszcze.Text) || textBoxTluszcze.Text == "0")
            {
                double b = Convert.ToDouble(textBoxTluszczeGramy.Text);
                textBoxTluszcze.Text = (b * 9).ToString();
            }
        }
    }
}
