﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace BMR
{
    public partial class Rejestracja : Form
    {                
        public Rejestracja()
        {
            InitializeComponent();
        }

        
        private void Zarejestrujsie_b_Click(object sender, EventArgs e)
        {
            Odczyt();                                                    // wywołnie funkcji Odczyt
            if (Odczyt() == true)                                       // jeśli funkcja Odczyt zwraca wartość true to:
            {
                DialogResult dialog1 = MessageBox.Show("Login zajęty, spróbuj ponownie.", "", MessageBoxButtons.OK);    // zostaje wyświetlone okienko z informacją i przyciskiem "OK"
                if (dialog1 == DialogResult.OK)    // po kliknięciu przycisku "OK"
                {
                    this.Close();                  // zamknięcie aktualnego otwartego okna, w tym wypadku okno Rejestracja
                    new Rejestracja().Show();      // stworzenie nowego okna Rejestracja                         
                    return;                        // pominięcie reszty warunków (if'ów)
                }

            }

            if (string.IsNullOrWhiteSpace(login_tb.Text) || (string.IsNullOrWhiteSpace(haslo_tb.Text)) || (string.IsNullOrWhiteSpace(haslo2_tb.Text)))            // jeśli w text boxie "login" lub w text boxie "haslo" nie będzie znaków to:
            {
                MessageBox.Show("Podano nieprawidłowy login lub hasło");          // wyświetli się komunikat o błędzie
                return;                                                           // i reszta warunków zostanie pominięta
            }

            if (haslo_tb.Text != haslo2_tb.Text)                                 // jeśli hasła nie zgadzają się ze sobą to:
            {
                MessageBox.Show("Podane hasła różnią się");                    // wyświetli się komunikat o błędzie
            }                              
            else                       // jeśli zgadzają się to:
            {
                ZapisDo();  // wywołanie funkcji ZapisDo

                DialogResult dialog = MessageBox.Show("Rejestracja pomyślna!\n\nZostaniesz przeniesiony do menu głównego.", "", MessageBoxButtons.OK);   // i wyświetlenie komunikatu i przycisku "OK"
                if (dialog == DialogResult.OK)           // po kliknięciu w przycisk "OK" :
                {
                    this.Close();                       // zamknięcie okna Rejestracja(aktualnie otwarte okno)
                    new Form1().Show();                 // przejście do okna Form1(menu główne)
                }
            }
        }
        private void Powrot1_b_Click(object sender, EventArgs e)     // powrót do menu po kliknięciu w przycisk "Powrót do menu"
        {
            this.Close();
            new Form1().Show();
        }


        public void ZapisDo()                         // funkcja ZapisDo zapisuje zawartość text boxa "login" oraz "haslo" do pliku tekstowego
        {
            
            string path = @"C:\Users\marty\Desktop\BMRlist.txt";
            StreamWriter sw = new StreamWriter(path,true);
            sw.Write(login_tb.Text +" | ");
            sw.WriteLine(haslo_tb.Text);
            sw.WriteLine("");
            sw.Close();
        }
        public bool Odczyt()                   // funkcja Odczyt odczytuje zawartość pliku tekstowego i 
        {
            StringBuilder sb = new StringBuilder();
            string path = @"C:\Users\marty\Desktop\BMRlist.txt";
            StreamReader sr = new StreamReader(path);
            string s;
            
            s = sr.ReadToEnd();           // przypisanie tekstu z pliku tekstowego do zmiennej string
           
            sr.Close();

            bool a = s.Contains(login_tb.Text);      // sprawdza czy w pliu tekstowym istnieje słowo zawarte w text boxie "login"

            if(a == true)                           // jeśli tak :
            {
                return true;                       // funkcja zwraca true
            }
            return false;                            // a jeśli nie to false
           
       


            
            
        }
    }
}


