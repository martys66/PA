﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BMR
{
    public partial class Logowanie : Form
    {
        public string nazwaUżytkownika = "";
        public Logowanie()
        {
            InitializeComponent();
        }

        private void Zalogujsie_b_Click(object sender, EventArgs e)
        {
                                                                                                                   
            if (string.IsNullOrWhiteSpace(loginLogowanie_tb.Text) || (string.IsNullOrWhiteSpace(hasloLogowanie_tb.Text)))       // jeśli w text boxie "loginLogowanie" lub w text boxie "hasloLogowanie" nie będzie znaków to:
            {
                MessageBox.Show("Błędne dane, spróbuj ponownie");                                                               // zostanie wyświetlony komunikat o błędzie
                return;                                                                                                         // pominięcie kolejnych warunków 
            }



            Logowaniesie();                                                                                                     // wywołanie funkcji LogowanieSie

            if (Logowaniesie() == true)                                                                                         // jeśli funkcja zwraca wartość true to:
            {
                DialogResult dialog = MessageBox.Show("Logowanie pomyślne, " + loginLogowanie_tb.Text + "!", "", MessageBoxButtons.OK);   
                if (dialog == DialogResult.OK)
                {
                   
                    nazwaUżytkownika = loginLogowanie_tb.Text;   // przypisanie zmiennej wartości w textBoxie
                    this.Close();
                    new LiczenieBMR(this).Show();    //   stworzenie okna LiczenieBMR dziedziczącego wartości z okna Logowanie(this)
                }
                                                          
            }
            else                                                                                                                // jeśli funckja zwróci inną wartość niż true(czyli false) to:
            {
                MessageBox.Show("Podano nieprawidłowy login lub hasło");                                                        // zostanie wyświetlony komunikt o błędzie
            }
        }

        private void PowrotLogowanie_b_Click(object sender, EventArgs e)
        {
            this.Close();                                                                                                      // zamknięcie okna Logowanie
            new Form1().Show();                                                                                                // przejście do okna Form1(powrót do menu głównego)                                                                        
        }

        public bool Logowaniesie()
        {
            StringBuilder sb = new StringBuilder();                                  // odczyt z pliku
            string path = @"C:\Users\marty\Desktop\BMRlist.txt";
            StreamReader sr = new StreamReader(path);
            string s;

            s = sr.ReadToEnd();                  // przypisanie tekstu z pliku tekstowego do zmiennej string

            sr.Close();

            bool a = s.Contains(loginLogowanie_tb.Text);    // sprawdzenie czy w pliku tekstowym znajduje się dane słowo(login)
            bool b = s.Contains(hasloLogowanie_tb.Text);    // sprawdzenie czy w pliku tekstowym znajduje się dane słowo(hasło)
            
            
            if (a == true && b == true)              // jeśli znajduje się login i hasło to:
            {
                return true;                        // funkcja LogowanieSie zwraca true (funkcja bool)
            }
            else                                   // jeśli nie znajduje 
            {
                return false;                      // funkcja LogowanieSie zwraca false (funkcja bool)
            }
            

        }

     
    }
    
}

