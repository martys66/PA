﻿namespace BMR
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.Logowanie_b = new System.Windows.Forms.Button();
            this.Rejestracja_b = new System.Windows.Forms.Button();
            this.Exit_b = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox2
            // 
            this.textBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.textBox2.Location = new System.Drawing.Point(0, 0);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox2.Size = new System.Drawing.Size(800, 21);
            this.textBox2.TabIndex = 1;
            this.textBox2.Text = "No elo wariacik chcesz sobie obliczyć zapotrzebowanie kaloryczne? Jeśli nie to sp" +
    "ierdalaj, ale jeśli tak to zarejestruj się i zostań członkiem rodzinki sportowyc" +
    "h świrków wariaciku ";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Logowanie_b
            // 
            this.Logowanie_b.Location = new System.Drawing.Point(308, 68);
            this.Logowanie_b.Name = "Logowanie_b";
            this.Logowanie_b.Size = new System.Drawing.Size(200, 100);
            this.Logowanie_b.TabIndex = 0;
            this.Logowanie_b.Text = "Logowanie";
            this.Logowanie_b.UseVisualStyleBackColor = true;
            this.Logowanie_b.Click += new System.EventHandler(this.Logowanie_b_Click);
            // 
            // Rejestracja_b
            // 
            this.Rejestracja_b.Location = new System.Drawing.Point(308, 186);
            this.Rejestracja_b.Name = "Rejestracja_b";
            this.Rejestracja_b.Size = new System.Drawing.Size(200, 100);
            this.Rejestracja_b.TabIndex = 2;
            this.Rejestracja_b.Text = "Rejestracja";
            this.Rejestracja_b.UseVisualStyleBackColor = true;
            this.Rejestracja_b.Click += new System.EventHandler(this.Rejestracja_b_Click);
            // 
            // Exit_b
            // 
            this.Exit_b.Location = new System.Drawing.Point(308, 306);
            this.Exit_b.Name = "Exit_b";
            this.Exit_b.Size = new System.Drawing.Size(200, 100);
            this.Exit_b.TabIndex = 3;
            this.Exit_b.Text = "Exit";
            this.Exit_b.UseVisualStyleBackColor = true;
            this.Exit_b.Click += new System.EventHandler(this.Exit_b_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Exit_b);
            this.Controls.Add(this.Rejestracja_b);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.Logowanie_b);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu główne";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button Logowanie_b;
        private System.Windows.Forms.Button Rejestracja_b;
        private System.Windows.Forms.Button Exit_b;
    }
}

